export class Player {
    name: string = "";
    description: string = "";
    image: string = "";
    followers:number = 0;
    trophies: number = 0;
    url: string = "";
}
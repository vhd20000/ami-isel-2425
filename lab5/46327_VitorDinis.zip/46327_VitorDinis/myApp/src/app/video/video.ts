export class Video {
    id: number = 0;
    name: string = "";
    description: string = "";
    image: string = "";
    url: string = "";
}
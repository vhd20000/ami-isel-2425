export class Task {
    $key: any;
    title: string = "";
    status: string = "";
}
